package com.cyberbox.arslonbek;

/**
 * @author Arslonbek Erkinov
 *
 * Простая Анимация загрузки для консоли в Java
 * */

public class Main {

    private String s = "";
    private byte animation;

    public void print(String line) {
        if (s.length() > line.length()) {
            String temp = "";
            for (int i = 0; i < s.length(); i++) {
                temp += " ";
            }
            if (temp.length() > 1)
                System.out.print("\r" + temp);
        }
        System.out.print("\r" + line);
        s = line;
    }

    public void Loading(String line) {
        switch (animation) {
            case 1:
                print("[ \\ ] " + line);
                break;
            case 2:
                print("[ | ] " + line);
                break;
            case 3:
                print("[ / ] " + line);
                break;
            default:
                animation = 0;
                print("[ - ] " + line);
        }
        animation++;
    }

    public static void main(String[] args) throws InterruptedException {
        Main m = new Main();
        for (int i = 0; i < 50; i++) {
            m.Loading(i + "");
            Thread.sleep(400);
        }
    }
}
